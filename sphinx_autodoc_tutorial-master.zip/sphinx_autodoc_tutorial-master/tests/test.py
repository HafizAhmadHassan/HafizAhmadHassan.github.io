import autos

if __name__ == "__main__":
    b = autos.Bike(name="SR400")
    b.ride(road="101")